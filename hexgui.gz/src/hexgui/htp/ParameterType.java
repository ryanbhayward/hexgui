// ParameterType.java

package hexgui.htp;

/** Paremeter types in analyze commands of type "param". */
public enum ParameterType
{
    STRING,

    BOOL,

    LIST
}
